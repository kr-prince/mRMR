************************************************************************

This is script generated file for mRmRApp 1.0
System Time : 20-May-2016  1300Hrs
----- Beginning List of Files -----

Input Data          : D:/mrmr/data/colonData.csv
Nature of Data      : Continuous
mRMR Selected       : Yes
No. of Features     : 24
Reduced Data(FCD)   : reducedData.csv
Optimal Data Reqd   : No
Classify Selected   : Yes
Classification Data : Reduced DataSet
Classification Stats: class_reducedData.txt

Test Run Completed..

************************************************************************

